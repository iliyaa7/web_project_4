# web_project_4 by Iliya Gomon

This is my fifth project at the yandex web development course.

In this project I continued applying front-end js features to my responsive "Social Network" that i built on my privious project.
This time I've added funcionalety to all the buttons in the page and made some new popups.
Users can now add new posts and chose thier own pictures (via a link for the pic) and they can even delete the posts they dont want.
I used varubels, objects, dom selector, function, conditions, arrays methods, event objects and event listeners in oreder to make all the above happen.
After that i refactored the code according to the OOP metodolgy.

In the near future I am planning to make the buttons act smothly (some buttons are pressable only on thier image) and correcting closing form issue (a little bug accurs if you try to close the popup via overlay. the popup closes even if only the release of the click hepans on the overlay)
And adding the resetFormValidation function that will reset the fields and errors after the popup is closed/

git hub pages link - https://iliyaa7.github.io/web_project_4/
